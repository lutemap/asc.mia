---
title: Hakkında
layout: about
permalink: /about.html
credits: true
---

## Proje hakkında

Ankara Devlet Konservatuvarı Çalgı Arşivi organolojik dijital envanterinin ön gösterimi. Veriler Kasım 2026 tarihli MasterData dosyasından aktarılmıştır. Sınıflandırma ve tanımlamalar kaynak envanterdeki biçimleriyle korunmuştur.

Bu site açık kaynak [CollectionBuilder-CSV](https://github.com/CollectionBuilder/collectionbuilder-csv) altyapısıyla oluşturulmuştur.

Fotoğrafların ve üst verilerin çevrimiçi görüntülenmesi yeniden kullanım izni anlamına gelmez.
