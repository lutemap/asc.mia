---
title: Hakkında
layout: about
permalink: /about.html
credits: true
---

## Dijital Envanter Hakkında

Bu platform, Ankara Devlet Konservatuvarı Çalgı Arşivi'nin organolojik dijital envanterinin oluşturulmasına yönelik yürütülen çalışmalar kapsamında, [CollectionBuilder-CSV](https://github.com/CollectionBuilder/collectionbuilder-csv) altyapısı kullanılarak geliştirilmiştir.

Platformun mevcut sürümü; dijital envanter sisteminin işlevselliğini, üst veri yapısını, organolojik sınıflandırma yaklaşımını ve koleksiyonun dijital ortamda sunum olanaklarını ortaya koymak amacıyla hazırlanmış bir arayüz prototipi ve ön gösterim niteliğindedir.

Envanter verilerinin, görsel materyallerin ve dijital sunum bileşenlerinin geliştirilmesine yönelik çalışmalar devam etmekte olup mevcut sürüm, koleksiyonun nihai dijital yayını niteliğinde değildir.

Veriler Kasım 2026 tarihli MasterData dosyasından aktarılmıştır. Sınıflandırma ve tanımlamalar kaynak envanterdeki biçimleriyle korunmuştur.

Fotoğrafların ve üst verilerin çevrimiçi görüntülenmesi yeniden kullanım izni anlamına gelmez.

## Çalışma Grubu

- Prof. Dr. Cenk GÜRAY
- Prof. Burak TÜZÜN
- Arş. Gör. Tunahan ALAN
- Cengiz ÖZEN
