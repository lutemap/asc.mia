---
title: Veri tablosu
layout: data
permalink: /data.html
---

## Envanter verileri

Aranabilir ve sıralanabilir organolojik üst veri tablosu.
