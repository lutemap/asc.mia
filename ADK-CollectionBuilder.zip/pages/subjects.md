---
title: Sınıflandırma
layout: cloud
permalink: /subjects.html
cloud-fields: site.data.theme.subjects-fields
---

## Organolojik sınıflandırma

Terimler ilgili envanter kayıtlarına yönlendirir.
